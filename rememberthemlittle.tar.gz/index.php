<?php

require_once 'src/index.php';